<!DOCTYPE HTML>

<html>
<body>
<form method="post" style="display:inline-block;border:1px solid black;padding:15px;" action="php_exer3.2compute.php">
<h2>PHP Exercise 3.2:</br>
PHP PC Shop</h2>
  <p>Processor
  <p>
    <label>
      <input type="checkbox" name="processor[]" value="15000.00"/> Intel i7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="processor[]" value="8000.00"> Intel Quad Core
    </label>
  </p>
  <p>
    <label>
      <input type="checkbox" name="processor[]" value="13000.00"/> Intel i5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="checkbox" name="processor[]" value="6000.00"> Intel Dual Core
  </p>
  <p>
    <label>
      <input type="checkbox" name="processor[]" value="10000.00"> Intel i3 
  </p>
 
  <p>RAM
  <p>
    <label>
      <input type="checkbox" name="ram[]" value="10000.00">16 GB &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="checkbox" name="ram[]" value="4000.00"> 4 GB
    </label>                                               
  </p>                                                     
  <p>                                                      
    <label>                                                
      <input type="checkbox" name="ram[]" value="8000.00">8 GB  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="checkbox" name="ram[]" value="2000.00">2 GB
  </p>                                                   
                                                     
  <p>Accesories
<p> 
    <label>                                                
      <input type="checkbox" name="accessories[]" value="3000.00">Gaming Keyboard
    </label>                                                
  </p>
   <p>      
   
    <label>                                                
      <input type="checkbox" name="accessories[]" value="2000.00">Gaming Mouse
    </label>                                                
  </p>
   <p>                                                      
    <label>                                                
      <input type="checkbox" name="accessories[]" value="3500.00">Gaming Headset
    </label>                                                
  </p>
  <p>
  <BR>
    <input type="submit" name="submit" value="COMPUTE">
  </p>
</form>
</body>
</html>
