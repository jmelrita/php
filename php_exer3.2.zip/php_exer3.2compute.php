
<?php

if (isset($_POST['submit'])) {
  $total = 0;
  $selected_processor = array();
  if (!empty($_POST['processor'])) {
    foreach ($_POST['processor'] as $selected_proc) {
      $total += $selected_proc;
      $selected_processor[] = $selected_proc;
    }
  }
   $selected_ram = array();
  if (!empty($_POST['ram'])) {
    foreach ($_POST['ram'] as $selected_ra) {
      $total += $selected_ra;
      $selected_ram[] = $selected_ra;
    }
  }
   $selected_accessories= array();
  if (!empty($_POST['accessories'])) {
    foreach ($_POST['accessories'] as $selected_acc) {
      $total += $selected_acc;
      $selected_accessories[] = $selected_acc;
    }
  }
  
  
  ?>
	<style>
	p{
		font-weight:bold;
	}
	</style>
  <form method="post" style="display:inline-block;border:1px solid black;padding:10px;" >
  <h2>PHP Exercise 3.2 <br>
  PHP PC Shop</h2>
  <ol>
 
     <?php  echo "Processor: ";
	foreach ($selected_processor as $key => $item) { ?>
      <?php if ($item == 15000) { ?>
         <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intel i7</li>
      <?php } else if ($item == 13000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intel i5 </li>
      <?php } else if ($item == 10000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intel i3 </li>
      <?php } else if ($item == 8000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intel Quad Core </li>
      <?php } else if ($item == 6000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intel Dual Core
      <?php } ?>
    <?php } ?>	
  </ol>
  
  <ol>

    <?php echo "RAM: ";
	foreach ($selected_ram as $key2 => $item2) { ?> 
	
      <?php  if ($item2 == 10000) { ?>
         <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;16 GB</li>
      <?php } else if ($item2 == 8000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;8 GB</li>
      <?php } else if ($item2 == 4000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4 GB </li>
      <?php } else if ($item2 == 2000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2 GB</li>
      <?php } ?>
    <?php } ?>	
  </ol>
  <ol>

    <?php echo "Accessories: ";
	foreach ($selected_accessories as $key3 => $item3) { ?>
	
      <?php if ($item3 == 3000) { ?>
         <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gaming Keyboard</li>
      <?php } else if ($item3 == 2000) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gaming Mouse</li>
      <?php } else if ($item3 == 3500) { ?>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gaming Headset </li>
      <?php } ?>
    <?php } ?>	
  </ol>

  
  <p>Total Price: <?php echo number_format($total, 2); ?></p>
  </form>
  <?php
  
  
  
}
?>