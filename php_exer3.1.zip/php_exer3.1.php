<!DOCTYPE html>
<html>
<head>
	<title>Salary Calculator</title>
</head>
<body>
	
	<form method="post" action="php_exer3.1compute.php" style="display:inline-block;border:1px solid black;padding:15px;">
<h2>PHP Exercises 3.1</h2>
		<label for="day_of_works">No. of days worked:</label>
		<input name="day_of_works" id="day_of_works" required><br><br>

		<label for="employee_status">Employee Status:</label>
		<select name="employee_status" id="employee_status">
			<option value="Regular">Regular</option>
			<option value="Probationary">Probationary</option>
			<option value="Casual">Casual</option>
		</select><br><br>

		<label for="civil_status">Civil Status:</label>
		<select name="civil_status" id="civil_status">
			<option value="Single">Single</option>
			<option value="Married">Married</option>
			<option value="Widowed">Widowed</option>
		</select><br><br>

		<input type="submit" value="Calculate Salary">
	</form>
	</body>
</html>