<?php
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
			$day_of_works = $_POST['day_of_works'];
			$employee_status = $_POST['employee_status'];
			$civil_status = $_POST['civil_status'];
			$tax;
			switch ($employee_status) {
				case 'Regular':
					$salary_rate = 500.00;
					$tax_rate = 12;
					break;
				case 'Probationary':
					$salary_rate = 400.00;
					$tax_rate = 10;
					break;
				case 'Casual':
					$salary_rate = 300.00;
					$tax_rate = 7;
					break;
				default:
					$salary_rate = 0;
					$tax_rate = 0;
					break;
			}

			switch ($civil_status) {
				case 'Single':
					$tax_rate = 12;
					$tax=12;
					break;
				case 'Married':
					$tax_rate = 10;
					$tax=10;
					break;
				case 'Widowed':
					$tax_rate = 7;
					$tax=7;
					break;
				default:
					$tax_rate = 0;
					$tax=0;
					break;
			}

			$gross_pay = $day_of_works * $salary_rate;
			$tax_amount = $gross_pay * ($tax_rate / 100);
			$net_salary = $gross_pay - $tax_amount;
			echo "<form style='display:inline-block;border:1px solid black;padding:15px;'>";
			echo "<h2>PHP Exercises 3.1</h2>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;No. of days worked: $day_of_works<br>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Employee Status: $employee_status<br>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Civil Status: $civil_status<br><br>";
			echo "<fieldset><legend style='font-weight: bold;'>Result</legend>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Gross Salary: ".number_format($gross_pay,2)."<br>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Tax: $tax% <br>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Deduction: ". number_format($tax_amount, 2) ."<br>";
			echo "&nbsp;&nbsp;&nbsp;&nbsp;Net Salary: ".number_format($net_salary, 2) ."<br>";
			
		}
	?>